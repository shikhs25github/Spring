package clientDemo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Scope;

import aspect.AspectModule;
import beans.Address;
import beans.Employee;

@Configuration
@ComponentScan("beans,aspect")
@EnableAspectJAutoProxy
public class ConfigClass {

	@Bean
	@Scope("prototype")
	public Employee employee()
	{
		//Employee e= new Employee("100","Shikha",0d,address());
		//return e;
		return new Employee();
	}
	
	@Bean
	public Address address()
	{
		//Address add= new Address("Lucknow",411057L);
		//return add;
		return new Address();
	}
	
	@Bean
	public AspectModule aspectModule()
	{
		return new AspectModule();
	}
}

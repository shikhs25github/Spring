package clientDemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import beans.Employee;

public class Demo1 {

	public static void main(String[] args) {
		
		@SuppressWarnings("resource")
		//ApplicationContext cont= new ClassPathXmlApplicationContext("config.xml");
		ApplicationContext cont= new AnnotationConfigApplicationContext(ConfigClass.class);
		Employee emp =(Employee)cont.getBean("employee");
		double salaryIncrement=emp.calculateIncrement("Hello World!");
		System.out.println("Incremented Salary: "+salaryIncrement);
		/*try
		{
			emp.throwingException();
		}
		catch(Exception e)
		{
			System.out.println("Exception received in Demo class: "+e.toString());
		}*/
		/*System.out.println("Emo id: "+emp.getEmpid());
		System.out.println("Emp name: "+emp.getEmpname());
		System.out.println("Emp salary: "+emp.getSalary());
		System.out.println("Area: "+emp.getAddress().getArea());
		System.out.println("Pincode: "+emp.getAddress().getPincode());*/
		//Check scope
		/*emp.setEmpid("300");
		Employee emp2= (Employee) cont.getBean("employee");
		System.out.println(emp2.getEmpid());*/
	}

}

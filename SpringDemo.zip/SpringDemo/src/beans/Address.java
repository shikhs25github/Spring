package beans;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Address {
	@Value("Pune")
	private String area;
	@Value("411057")
	private Long pincode;
	
	public Address() {
	}
	
	public Address(String area, Long pincode) {
		super();
		this.area = area;
		this.pincode = pincode;
	}
	
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public Long getPincode() {
		return pincode;
	}
	public void setPincode(Long pincode) {
		this.pincode = pincode;
	}
}

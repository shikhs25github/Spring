package beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
//@Scope("prototype")
public class Employee {
	@Value("200")
	private String empid;
	@Value("dolly")
	private String empname;
	@Value("40000.50")
	private Double salary;
	@Autowired
	//@Qualifier("address2")
	private Address address;
	
	public Employee() {
		super();
	}
	//@Autowired
	public Employee(String empid, String empname, Double salary, Address address) {
		super();
		this.empid = empid;
		this.empname = empname;
		this.salary = salary;
		this.address = address;
	}
	public String getEmpid() {
		return empid;
	}
	public void setEmpid(String empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public Address getAddress() {
		return address;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	//@Autowired
	//@Qualifier("address2")
	public void setAddress(Address address) {
		this.address = address;
	}
	public Double calculateIncrement(String msg)	{
		System.out.println("Inside method calculateIncrement");
		if(salary<=1000)
			salary+=salary*0.2;
		else if(salary<=3000)
			salary+=salary*0.5;
		else
			salary+=salary*0.7;
		return salary;
	}
	public void throwingException()
	{
		System.out.println("Inside method throwingException");
		String str="hello";
		int res= Integer.parseInt(str);
		System.out.println(res);
	}
}

package aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class AspectModule {

	@Before("execution(* beans.Employee.calculateIncrement(*))")
	public void doBeforeTask()
	{
		System.out.println("Inside method doBeforeTask");
	}
	
	@After("execution(* beans.Employee.calculateIncrement(*))")
	public void doAfterTask()
	{
		System.out.println("Inside method doAfterTask");
	}
	
	@AfterReturning(pointcut= "execution(* beans.Employee.calculateIncrement(*))", returning ="retval")
	public double doAfterReturningTask(double retval)
	{
		System.out.println("Inside method doAfterReturningTask");
		retval+=5000;
		System.out.println("Returned value: "+retval);
		return retval;
	}
	
	@AfterThrowing(pointcut= "execution(* beans.Employee.throwingException())", throwing= "e")
	public void doAfterThrowingTask(Exception e)
	{
		System.out.println("Inside method doAfterThrowingTask");
		System.out.println("Exception thrown: "+e.toString());
	}
	
	@Around("execution(* beans.Employee.calculateIncrement(*))")
	public Object doAroundTask(ProceedingJoinPoint pjp) throws Throwable
	{
		System.out.println("Inside method doAroundTask");
		System.out.println("Before proceed");
		Object retval= pjp.proceed();
		System.out.println("After proceed");
		double salary= (double)retval;
		System.out.println("salary in doAroundTask: "+salary);
		Object args[]= pjp.getArgs();
		String msg= args[0].toString();
		System.out.println("Message in doAroundTask: "+msg);
		salary+=1000;
		return salary;
	}
}
